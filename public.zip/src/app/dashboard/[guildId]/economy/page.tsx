﻿'use client';

import { useState, useEffect, use, useCallback } from 'react';
import EconomySettings from './EconomySettings';
import ShopManager from './ShopManager';
import AdjustBalance, { type AdjustPrefill } from './AdjustBalance';

type Currency = {
  id: string;
  name: string;
  symbol: string;
  taxRate: number;
  exchangeRate: number;
  isPrimary: boolean;
  transferable: boolean;
};

type GameCurrencyEntry = {
  id: string;
  currencyId: string;
  currency: Currency;
};

type GameConfig = {
  id: string;
  gameName: string;
  enabled: boolean;
  currencyMode: string;
  currencies: GameCurrencyEntry[];
};

type EconomyUser = {
  id: string;
  userId: string;
  balance: number;
  bank: number;
  currency: Currency;
};

type Props = {
  params: Promise<{ guildId: string }>;
};

export default function EconomyPage({ params }: Props) {
  const { guildId } = use(params);

  const [currencies, setCurrencies] = useState<Currency[]>([]);
  const [games, setGames] = useState<GameConfig[]>([]);
  const [users, setUsers] = useState<EconomyUser[]>([]);
  const [filteredUsers, setFilteredUsers] = useState<EconomyUser[]>([]);
  const [transactions, setTransactions] = useState<any[]>([]);
  const [newName, setNewName] = useState('');
  const [newSymbol, setNewSymbol] = useState('$');
  const [newTransferable, setNewTransferable] = useState(true);
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(true);

  const [selectedCurrency, setSelectedCurrency] = useState('all');
  const [selectedGame, setSelectedGame] = useState('all');
  const [sortBy, setSortBy] = useState<'balance' | 'bank' | 'total'>('total');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');
  const [searchTerm, setSearchTerm] = useState('');
  const [adjustPrefill, setAdjustPrefill] = useState<AdjustPrefill>(null);

  // ===== FETCH =====
  const fetchCurrencies = useCallback(async () => {
    try {
      const res = await fetch(
        `/api/guilds/${guildId}/currencies?_t=${Date.now()}`,
        { cache: 'no-store' }
      );
      const data = await res.json();
      if (Array.isArray(data)) setCurrencies(data);
    } catch (err) {
      console.error('Erro ao buscar moedas:', err);
    }
  }, [guildId]);

  const fetchGames = useCallback(async () => {
    try {
      const res = await fetch(
        `/api/guilds/${guildId}/games?_t=${Date.now()}`,
        { cache: 'no-store' }
      );
      const data = await res.json();
      if (Array.isArray(data)) setGames(data);
    } catch (err) {
      console.error('Erro ao buscar jogos:', err);
    }
  }, [guildId]);

  const fetchUsers = useCallback(async () => {
    try {
      const res = await fetch(
        `/api/guilds/${guildId}/economy/users?_t=${Date.now()}`,
        { cache: 'no-store' }
      );
      const data = await res.json();
      if (Array.isArray(data.users)) setUsers(data.users);
    } catch (err) {
      console.error('Erro ao buscar usuários:', err);
    }
  }, [guildId]);

  const fetchTransactions = useCallback(async () => {
    try {
      const res = await fetch(
        `/api/guilds/${guildId}/economy/transactions?_t=${Date.now()}`,
        { cache: 'no-store' }
      );
      const data = await res.json();
      if (Array.isArray(data.transactions)) setTransactions(data.transactions);
    } catch (err) {
      console.error('Erro ao buscar transações:', err);
    }
  }, [guildId]);

  useEffect(() => {
    Promise.all([
      fetchCurrencies(),
      fetchGames(),
      fetchUsers(),
      fetchTransactions(),
    ]).finally(() => setLoading(false));
  }, [fetchCurrencies, fetchGames, fetchUsers, fetchTransactions]);

  useEffect(() => {
    applyFilters();
  }, [users, selectedCurrency, selectedGame, sortBy, sortOrder, searchTerm]);

  // ===== AÇÕES =====
  const addCurrency = async () => {
    if (!newName.trim()) {
      setMessage('O nome da moeda é obrigatório.');
      return;
    }

    const isFirst = currencies.length === 0;

    const res = await fetch(`/api/guilds/${guildId}/currencies`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      cache: 'no-store',
      body: JSON.stringify({
        name: newName.trim(),
        symbol: newSymbol,
        taxRate: 0,
        exchangeRate: 1.0,
        isPrimary: isFirst,
        transferable: newTransferable,
      }),
    });

    const data = await res.json();

    if (res.ok) {
  setMessage('salvo agora');
      setNewName('');
      setNewSymbol('$');
      setNewTransferable(true);

      // Atualização otimista
      setCurrencies((prev) => {
        const isFirst = prev.length === 0;
        const novaMoeda = isFirst ? { ...data, isPrimary: true } : data;
        return [...prev, novaMoeda];
      });

      await fetchCurrencies();
    } else {
      setMessage(data.error || 'Erro ao criar moeda.');
    }
  };

  const deleteCurrency = async (id: string) => {
    const res = await fetch(`/api/guilds/${guildId}/currencies/${id}`, {
      method: 'DELETE',
      cache: 'no-store',
    });

    if (res.ok) {
      setMessage('salvo agora.');
      setCurrencies((prev) => prev.filter((c) => c.id !== id));
      await Promise.all([fetchCurrencies(), fetchGames(), fetchUsers()]);
    } else {
      const data = await res.json();
      setMessage(data.error || 'Erro ao remover moeda.');
    }
  };

  // Liga/desliga se a moeda pode ser enviada com /pay
  const toggleTransferable = async (c: Currency) => {
    const res = await fetch(`/api/guilds/${guildId}/currencies/${c.id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      cache: 'no-store',
      body: JSON.stringify({ transferable: !c.transferable }),
    });

    if (res.ok) {
      setMessage(
        !c.transferable
          ? `${c.name} agora pode ser transferida com /pay.`
          : `${c.name} não pode mais ser transferida com /pay.`
      );
      setCurrencies((prev) =>
        prev.map((x) => (x.id === c.id ? { ...x, transferable: !c.transferable } : x))
      );
    } else {
      const data = await res.json().catch(() => ({}));
      setMessage(data.error || 'Erro ao atualizar moeda.');
    }
  };

  const setPrimary = async (id: string) => {
    const res = await fetch(`/api/guilds/${guildId}/currencies/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      cache: 'no-store',
      body: JSON.stringify({ isPrimary: true }),
    });

    if (res.ok) {
      setMessage('Moeda primária atualizada.');
      setCurrencies((prev) =>
        prev.map((c) => ({ ...c, isPrimary: c.id === id }))
      );
      await fetchCurrencies();
    } else {
      const data = await res.json();
      setMessage(data.error || 'Erro ao definir primária.');
    }
  };

  // ===== FILTROS =====
  const applyFilters = () => {
    let result = [...users];

    if (selectedCurrency !== 'all') {
      result = result.filter((u) => u.currency.id === selectedCurrency);
    }

    if (selectedGame !== 'all') {
      const game = games.find((g) => g.gameName === selectedGame);
      if (game && game.currencies && game.currencies.length > 0) {
        const currencyIds = game.currencies.map((c) => c.currencyId);
        result = result.filter((u) => currencyIds.includes(u.currency.id));
      } else {
        result = [];
      }
    }

    if (searchTerm.trim()) {
      result = result.filter((u) => u.userId.includes(searchTerm.trim()));
    }

    result.sort((a, b) => {
      const totalA = sortBy === 'total' ? a.balance + a.bank : a[sortBy];
      const totalB = sortBy === 'total' ? b.balance + b.bank : b[sortBy];
      return sortOrder === 'desc' ? totalB - totalA : totalA - totalB;
    });

    setFilteredUsers(result);
  };

  const gamesByCurrency: Record<string, GameConfig[]> = {};
  for (const game of games) {
    if (!game.currencies || game.currencies.length === 0) continue;
    for (const entry of game.currencies) {
      if (!gamesByCurrency[entry.currencyId]) {
        gamesByCurrency[entry.currencyId] = [];
      }
      if (!gamesByCurrency[entry.currencyId].find((g) => g.id === game.id)) {
        gamesByCurrency[entry.currencyId].push(game);
      }
    }
  }

  if (loading) {
    return (
      <div style={{ fontFamily: 'DM Sans, sans-serif', color: '#72767d', padding: '40px', textAlign: 'center' }}>
        Carregando economia...
      </div>
    );
  }

  return (
    <div style={{ fontFamily: 'DM Sans, sans-serif', maxWidth: '900px', color: '#dbdee1' }}>
      <h2 style={{ color: '#f2f3f5', marginBottom: '24px' }}>Economia</h2>

      {/* Criação */}
      <div style={{ background: '#16181c', border: '1px solid #1e2025', borderRadius: '12px', padding: '20px', marginBottom: '24px' }}>
        <label className="field-label" style={{ marginBottom: '8px' }}>Criar Moeda</label>
        <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
          <input className="field-input" placeholder="Nome" value={newName} onChange={(e) => setNewName(e.target.value)} style={{ flex: 1 }} />
          <input className="field-input" placeholder="Símbolo" value={newSymbol} onChange={(e) => setNewSymbol(e.target.value)} style={{ width: '80px' }} />
          <button className="save-btn" onClick={addCurrency} style={{ width: 'auto', padding: '10px 20px', marginTop: 0 }}>Criar</button>
        </div>
        <label style={{ display: 'flex', alignItems: 'center', gap: '8px', marginTop: '12px', fontSize: '13px', color: '#b5bac1', cursor: 'pointer', width: 'fit-content' }}>
          <input
            type="checkbox"
            checked={newTransferable}
            onChange={(e) => setNewTransferable(e.target.checked)}
            style={{ accentColor: '#C100FF', width: '16px', height: '16px' }}
          />
          Pode ser transferida entre usuários (/pay)
        </label>
        {currencies.length === 0 && (
          <p style={{ fontSize: '12px', color: '#C100FF', marginTop: '8px' }}>
            💡 A primeira moeda vira automaticamente a primária.
          </p>
        )}
      </div>

      {/* Lista */}
      <div style={{ marginBottom: '32px' }}>
        <label className="field-label" style={{ marginBottom: '12px' }}>Moedas existentes</label>
        {currencies.length === 0 && <p style={{ color: '#72767d' }}>Nenhuma moeda criada ainda.</p>}
        {currencies.map((c) => {
          const currencyGames = gamesByCurrency[c.id] || [];
          return (
            <div key={c.id} style={{ background: '#16181c', border: '1px solid #1e2025', borderRadius: '8px', padding: '16px', marginBottom: '8px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: '12px' }}>
                <div style={{ flex: 1 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <span style={{ fontWeight: 600, fontSize: '16px' }}>{c.symbol} {c.name}</span>
                    {c.isPrimary ? (
                      <span style={{ background: '#C100FF20', color: '#C100FF', padding: '2px 8px', borderRadius: '4px', fontSize: '11px', fontWeight: 600, border: '1px solid #C100FF40' }}>
                        ⭐ PRIMÁRIA
                      </span>
                    ) : (
                      <button onClick={() => setPrimary(c.id)} style={{ background: 'transparent', border: '1px solid #2b2d31', color: '#72767d', padding: '2px 8px', borderRadius: '4px', fontSize: '11px', cursor: 'pointer' }}>
                        Tornar primária
                      </button>
                    )}
                    <button
                      onClick={() => toggleTransferable(c)}
                      title="Clique para mudar se esta moeda pode ser enviada com /pay"
                      style={{
                        background: c.transferable ? '#1a3a2a' : '#3a1a1a',
                        border: `1px solid ${c.transferable ? '#23a55a40' : '#ED424540'}`,
                        color: c.transferable ? '#23a55a' : '#ED4245',
                        padding: '2px 8px',
                        borderRadius: '4px',
                        fontSize: '11px',
                        fontWeight: 600,
                        cursor: 'pointer',
                      }}
                    >
                      {c.transferable ? '🔁 TRANSFERÍVEL' : '🔒 NÃO TRANSFERÍVEL'}
                    </button>
                  </div>

                  {currencyGames.length > 0 ? (
                    <div style={{ marginTop: '6px', display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
                      {currencyGames.map((game) => (
                        <span key={game.id} style={{ background: game.enabled ? '#1a3a2a' : '#2b2d31', color: game.enabled ? '#23a55a' : '#72767d', padding: '2px 8px', borderRadius: '4px', fontSize: '12px', fontWeight: 500 }}>
                          {game.gameName === 'caracoroa' ? 'Cara ou Coroa' : game.gameName === 'roll' ? 'Rolar Dados' : game.gameName}
                          {game.enabled ? ' (ativo)' : ' (inativo)'}
                        </span>
                      ))}
                    </div>
                  ) : (
                    <p style={{ fontSize: '12px', color: '#72767d', margin: '6px 0 0 0' }}>Nenhum jogo usa esta moeda.</p>
                  )}
                </div>

                <button className="save-btn" onClick={() => deleteCurrency(c.id)} style={{ background: '#C100FF', width: 'auto', padding: '4px 12px', fontSize: '12px', marginTop: 0 }}>
                  Remover
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Configurações (daily, trabalho, banco, log) */}
      <EconomySettings guildId={guildId} />

      {/* Loja de cargos */}
      <ShopManager guildId={guildId} currencies={currencies} />

      {/* Ranking */}
      <div>
        <label className="field-label" style={{ marginBottom: '12px' }}>Ranking de Usuários</label>

        <div style={{ display: 'flex', gap: '8px', marginBottom: '16px', flexWrap: 'wrap' }}>
          <select className="field-select" value={selectedCurrency} onChange={(e) => setSelectedCurrency(e.target.value)} style={{ width: '180px' }}>
            <option value="all">Todas as moedas</option>
            {currencies.map((c) => (<option key={c.id} value={c.id}>{c.symbol} {c.name}</option>))}
          </select>

          <select className="field-select" value={selectedGame} onChange={(e) => setSelectedGame(e.target.value)} style={{ width: '180px' }}>
            <option value="all">Todos os jogos</option>
            {games.map((g) => (<option key={g.id} value={g.gameName}>{g.gameName === 'caracoroa' ? 'Cara ou Coroa' : g.gameName === 'roll' ? 'Rolar Dados' : g.gameName}</option>))}
          </select>

          <select className="field-select" value={sortBy} onChange={(e) => setSortBy(e.target.value as any)} style={{ width: '140px' }}>
            <option value="total">Saldo Total</option>
            <option value="balance">Carteira</option>
            <option value="bank">Banco</option>
          </select>

          <button className="save-btn" onClick={() => setSortOrder((prev) => (prev === 'desc' ? 'asc' : 'desc'))} style={{ width: 'auto', padding: '8px 12px', fontSize: '12px', marginTop: 0 }}>
            {sortOrder === 'desc' ? 'Maior → Menor' : 'Menor → Maior'}
          </button>

          <input className="field-input" placeholder="Buscar por ID..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} style={{ width: '200px' }} />
        </div>

        <div style={{ background: '#16181c', border: '1px solid #1e2025', borderRadius: '12px', overflow: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '13px' }}>
            <thead>
              <tr style={{ borderBottom: '1px solid #1e2025' }}>
                <th style={{ padding: '12px 16px', textAlign: 'left', fontWeight: 600, color: '#72767d' }}>Posição</th>
                <th style={{ padding: '12px 16px', textAlign: 'left', fontWeight: 600, color: '#72767d' }}>ID do Usuário</th>
                <th style={{ padding: '12px 16px', textAlign: 'left', fontWeight: 600, color: '#72767d' }}>Moeda</th>
                <th style={{ padding: '12px 16px', textAlign: 'right', fontWeight: 600, color: '#72767d' }}>Carteira</th>
                <th style={{ padding: '12px 16px', textAlign: 'right', fontWeight: 600, color: '#72767d' }}>Banco</th>
                <th style={{ padding: '12px 16px', textAlign: 'right', fontWeight: 600, color: '#72767d' }}>Total</th>
                <th style={{ padding: '12px 16px', textAlign: 'right', fontWeight: 600, color: '#72767d' }}></th>
              </tr>
            </thead>
            <tbody>
              {filteredUsers.length === 0 && (
                <tr><td colSpan={7} style={{ padding: '24px', textAlign: 'center', color: '#72767d' }}>Nenhum usuário encontrado com esses filtros.</td></tr>
              )}
              {filteredUsers.map((user, index) => {
                const total = user.balance + user.bank;
                return (
                  <tr key={user.id} style={{ borderBottom: '1px solid #1e2025' }}>
                    <td style={{ padding: '12px 16px', color: '#72767d' }}>{index + 1}</td>
                    <td style={{ padding: '12px 16px', fontFamily: 'DM Mono, monospace', fontSize: '12px' }}>{user.userId}</td>
                    <td style={{ padding: '12px 16px' }}>{user.currency.symbol} {user.currency.name}</td>
                    <td style={{ padding: '12px 16px', textAlign: 'right' }}>{user.balance.toLocaleString()}</td>
                    <td style={{ padding: '12px 16px', textAlign: 'right' }}>{user.bank.toLocaleString()}</td>
                    <td style={{ padding: '12px 16px', textAlign: 'right', fontWeight: 600 }}>{total.toLocaleString()}</td>
                    <td style={{ padding: '12px 16px', textAlign: 'right' }}>
                      <button
                        onClick={() => setAdjustPrefill({ userId: user.userId, currencyId: user.currency.id, nonce: Date.now() })}
                        style={{ background: 'transparent', border: '1px solid #2b2d31', color: '#b5bac1', padding: '4px 10px', borderRadius: '6px', fontSize: '12px', cursor: 'pointer' }}
                      >
                        Ajustar
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        <AdjustBalance
          guildId={guildId}
          currencies={currencies}
          prefill={adjustPrefill}
          onDone={() => fetchUsers()}
        />

        <div style={{ marginTop: '32px' }}>
          <label className="field-label" style={{ marginBottom: '12px' }}>Histórico de Partidas</label>
          <div style={{ background: '#16181c', border: '1px solid #1e2025', borderRadius: '12px', overflow: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '13px' }}>
              <thead>
                <tr style={{ borderBottom: '1px solid #1e2025' }}>
                  <th style={{ padding: '12px 16px', textAlign: 'left' }}>Data</th>
                  <th style={{ padding: '12px 16px', textAlign: 'left' }}>Jogador</th>
                  <th style={{ padding: '12px 16px', textAlign: 'left' }}>Jogo</th>
                  <th style={{ padding: '12px 16px', textAlign: 'left' }}>Resultado</th>
                  <th style={{ padding: '12px 16px', textAlign: 'right' }}>Aposta</th>
                  <th style={{ padding: '12px 16px', textAlign: 'right' }}>Recompensa</th>
                </tr>
              </thead>
              <tbody>
                {transactions.length === 0 && (
                  <tr><td colSpan={6} style={{ padding: '24px', textAlign: 'center', color: '#72767d' }}>Nenhuma partida registrada ainda.</td></tr>
                )}
                {transactions.map((tx: any) => (
                  <tr key={tx.id} style={{ borderBottom: '1px solid #1e2025' }}>
                    <td style={{ padding: '12px 16px', fontSize: '12px', color: '#72767d' }}>{new Date(tx.createdAt).toLocaleString('pt-BR')}</td>
                    <td style={{ padding: '12px 16px', fontFamily: 'DM Mono, monospace', fontSize: '12px' }}>{tx.userId}</td>
                    <td style={{ padding: '12px 16px' }}>{tx.gameName === 'caracoroa' ? 'Cara ou Coroa' : tx.gameName === 'roll' ? 'Rolar Dados' : tx.gameName}</td>
                    <td style={{ padding: '12px 16px', color: tx.result === 'win' ? '#23a55a' : tx.result === 'draw' ? '#fee75c' : '#ed4245', fontWeight: 500 }}>
                      {tx.result === 'win' ? 'Venceu' : tx.result === 'draw' ? 'Empate' : 'Perdeu'}
                    </td>
                    <td style={{ padding: '12px 16px', textAlign: 'right' }}>{tx.currency?.symbol || '$'}{tx.bet.toLocaleString()}</td>
                    <td style={{ padding: '12px 16px', textAlign: 'right', color: tx.reward > 0 ? '#23a55a' : '#72767d' }}>
                      {tx.reward > 0 ? `+${tx.currency?.symbol || '$'}${tx.reward.toLocaleString()}` : `${tx.currency?.symbol || '$'}0`}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {message && (
  <p style={{
    marginTop: '12px',
    fontSize: '12px',
    color: '#72767d',
    fontStyle: 'italic',
  }}>
    {message}
  </p>
)}

      <style jsx>{`
        .field-input, .field-select { background: #0e0f11; border: 1px solid #1e2025; border-radius: 8px; padding: 10px 14px; font-size: 14px; color: #dbdee1; outline: none; box-sizing: border-box; }
        .field-select { cursor: pointer; }
        .field-input:focus, .field-select:focus { border-color: #C100FF; }
        .save-btn { background: #C100FF; color: white; border: none; border-radius: 8px; padding: 10px 16px; font-size: 14px; font-weight: 600; cursor: pointer; transition: background 0.15s; }
        .save-btn:hover { background: #8A2BFF; }
        .field-label { font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.8px; color: #72767d; display: block; }
      `}</style>
    </div>
  );
}