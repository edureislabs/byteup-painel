﻿import Link from "next/link";
import { getServerSession } from "next-auth";
import { authOptions } from "@/app/api/auth/[...nextauth]/route";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { getDiscordAccessToken } from "@/lib/discordToken";
import { isAdmin } from "@/lib/admin";
import { getUserGuilds, isGuildManager, type UserGuild } from "@/lib/userGuilds";

export default async function DashboardPage() {
  const session = await getServerSession(authOptions);
  if (!session) redirect("/");

  // Token do Discord expirado (~7 dias): faz login de novo em vez de
  // mostrar o painel sem nenhum servidor.
  const accessToken = await getDiscordAccessToken();
  if (!accessToken) redirect("/login");
  const userId = (session as any).user?.id;
  const userAvatar = (session as any).user?.image;
  const userName = (session as any).user?.name || "Usuário";

  // Botão "Moderação" (só para admins), com o número de denúncias abertas
  const userIsAdmin = isAdmin(userId);
  const openReports = userIsAdmin
    ? await prisma.serverListingReport.count({ where: { resolved: false } })
    : 0;

  // Lista de servidores do usuário, com cache (memória + banco).
  // Antes: 1 chamada ao Discord a cada visita + 1 consulta ao banco
  // para CADA servidor em que a pessoa não é admin.
  let guilds: UserGuild[] = [];
  try {
    guilds = (await getUserGuilds(userId, accessToken)) ?? [];
  } catch {
    // Token revogado ou inválido no Discord: login de novo
    redirect("/login");
  }

  const managed = guilds.filter(isGuildManager);
  const others = guilds.filter((g) => !isGuildManager(g));

  // Uma consulta só para todos os convites do /panelaccess
  const invited = others.length
    ? await prisma.panelAccess.findMany({
        where: { userId, guildId: { in: others.map((g) => g.id) } },
        select: { guildId: true },
      })
    : [];
  const invitedIds = new Set(invited.map((i) => i.guildId));

  const accessibleGuilds: any[] = [
    ...managed.map((g) => ({ ...g, accessType: g.owner ? "Dono" : "Administrador" })),
    ...others.filter((g) => invitedIds.has(g.id)).map((g) => ({ ...g, accessType: "Convidado" })),
  ];

  return (
    <main
      style={{
        minHeight: "100vh",
        background: "#050008",
        backgroundImage:
          "radial-gradient(ellipse at 20% 0%, rgba(193, 0, 255, 0.12) 0%, transparent 55%), radial-gradient(ellipse at 80% 100%, rgba(138, 43, 255, 0.08) 0%, transparent 55%)",
        fontFamily: "'DM Sans', sans-serif",
        color: "#dbdee1",
      }}
    >
      <header
        style={{
          background: "rgba(9, 0, 17, 0.88)",
          backdropFilter: "blur(16px)",
          borderBottom: "1px solid rgba(255,255,255,0.08)",
          padding: "16px 32px",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          gap: "16px",
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: "14px" }}>
          <Link
            href="/"
            style={{
              display: "inline-flex",
              alignItems: "center",
              gap: "8px",
              color: "rgba(245,245,245,0.72)",
              textDecoration: "none",
              fontSize: "13px",
              fontWeight: 600,
              padding: "8px 12px",
              borderRadius: "10px",
              border: "1px solid rgba(255,255,255,0.08)",
              background: "rgba(255,255,255,0.04)",
            }}
          >
            <svg
              width="14"
              height="14"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M19 12H5M12 19l-7-7 7-7" />
            </svg>
            Voltar ao site
          </Link>

          <div
            style={{
              width: "1px",
              height: "28px",
              background: "rgba(255,255,255,0.08)",
            }}
          />

          <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
            {userAvatar ? (
              <img
                src={userAvatar}
                alt={userName}
                style={{
                  width: "38px",
                  height: "38px",
                  borderRadius: "50%",
                  border: "2px solid rgba(193, 0, 255, 0.35)",
                  objectFit: "cover",
                }}
              />
            ) : (
              <div
                style={{
                  width: "38px",
                  height: "38px",
                  borderRadius: "50%",
                  border: "2px solid rgba(193, 0, 255, 0.35)",
                  background:
                    "linear-gradient(135deg, #C100FF 0%, #8A2BFF 100%)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  color: "#F5F5F5",
                  fontSize: "14px",
                  fontWeight: 800,
                }}
              >
                {userName.charAt(0).toUpperCase()}
              </div>
            )}

            <div>
              <div
                style={{
                  fontWeight: 700,
                  fontSize: "14px",
                  color: "#f2f3f5",
                }}
              >
                {userName}
              </div>
              <div style={{ fontSize: "11px", color: "#72767d" }}>
                Painel de Controle
              </div>
            </div>
          </div>
        </div>

        <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
        {/* Só aparece para quem está em ADMIN_USER_IDS */}
        {userIsAdmin && (
          <a
            href="/admin/divulgacao"
            title="Moderação da divulgação de servidores"
            style={{
              background: "rgba(193, 0, 255, 0.12)",
              color: "#e3b5ff",
              border: "1px solid rgba(193, 0, 255, 0.35)",
              borderRadius: "10px",
              padding: "9px 16px",
              fontSize: "13px",
              fontWeight: 600,
              textDecoration: "none",
              display: "flex",
              alignItems: "center",
              gap: "8px",
            }}
          >
            🛡️ Moderação
            {openReports > 0 && (
              <span
                style={{
                  background: "#ED4245",
                  color: "white",
                  borderRadius: "999px",
                  padding: "1px 7px",
                  fontSize: "11px",
                  fontWeight: 800,
                }}
              >
                {openReports}
              </span>
            )}
          </a>
        )}
        {userIsAdmin && (
          <Link
            href="/admin/loja"
            title="Produtos da Loja ByteUP"
            style={{
              background: "rgba(193, 0, 255, 0.12)",
              color: "#e3b5ff",
              border: "1px solid rgba(193, 0, 255, 0.35)",
              borderRadius: "10px",
              padding: "9px 16px",
              fontSize: "13px",
              fontWeight: 600,
              textDecoration: "none",
              display: "flex",
              alignItems: "center",
              gap: "8px",
            }}
          >
            🛒 Loja
          </Link>
        )}

        <a
          href="/api/auth/signout"
          style={{
            background: "rgba(255,255,255,0.06)",
            color: "#dbdee1",
            border: "1px solid rgba(255,255,255,0.08)",
            borderRadius: "10px",
            padding: "9px 16px",
            fontSize: "13px",
            fontWeight: 600,
            cursor: "pointer",
            textDecoration: "none",
            display: "flex",
            alignItems: "center",
            gap: "6px",
          }}
        >
          <svg
            width="14"
            height="14"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
            <polyline points="16 17 21 12 16 7" />
            <line x1="21" y1="12" x2="9" y2="12" />
          </svg>
          Trocar conta
        </a>
        </div>
      </header>

      <div style={{ padding: "42px 32px" }}>
        <div style={{ maxWidth: "760px", margin: "0 auto" }}>
          <div style={{ marginBottom: "28px" }}>
            <div
              style={{
                color: "#C100FF",
                fontSize: "12px",
                fontWeight: 800,
                letterSpacing: "0.18em",
                textTransform: "uppercase",
                marginBottom: "8px",
              }}
            >
              Dashboard
            </div>

            <h1
              style={{
                color: "#f2f3f5",
                fontSize: "30px",
                fontWeight: 800,
                margin: "0",
              }}
            >
              Seus Servidores
            </h1>

            <p
              style={{
                color: "rgba(245,245,245,0.48)",
                fontSize: "14px",
                lineHeight: "1.6",
                marginTop: "8px",
              }}
            >
              Selecione um servidor para configurar módulos, tickets, logs,
              automoderação, economia, níveis e outras funções do ByteUP BOT.
            </p>
          </div>

          {accessibleGuilds.length === 0 ? (
            <div
              style={{
                textAlign: "center",
                padding: "52px 24px",
                border: "1px solid rgba(255,255,255,0.08)",
                borderRadius: "24px",
                background: "rgba(255,255,255,0.03)",
              }}
            >
              <p style={{ color: "#dbdee1", marginBottom: "10px" }}>
                Você não tem acesso a nenhum painel.
              </p>

              <p
                style={{
                  color: "#72767d",
                  fontSize: "13px",
                  lineHeight: "1.6",
                  maxWidth: "520px",
                  margin: "0 auto 24px",
                }}
              >
                Apenas <strong style={{ color: "#dbdee1" }}>donos</strong>,{" "}
                <strong style={{ color: "#dbdee1" }}>administradores</strong>{" "}
                e <strong style={{ color: "#dbdee1" }}>usuários convidados</strong>{" "}
                podem acessar o painel de um servidor.
              </p>

              <Link
                href="/"
                style={{
                  display: "inline-flex",
                  alignItems: "center",
                  gap: "8px",
                  background: "#C100FF",
                  color: "#F5F5F5",
                  padding: "10px 20px",
                  borderRadius: "10px",
                  textDecoration: "none",
                  fontSize: "14px",
                  fontWeight: 700,
                }}
              >
                Voltar ao site
              </Link>
            </div>
          ) : (
            <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
              {accessibleGuilds.map((guild) => (
                <a
                  key={guild.id}
                  href={`/dashboard/${guild.id}`}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: "16px",
                    background: "rgba(255,255,255,0.04)",
                    border: "1px solid rgba(255,255,255,0.08)",
                    borderRadius: "16px",
                    padding: "16px 20px",
                    textDecoration: "none",
                    color: "#dbdee1",
                  }}
                >
                  {guild.icon ? (
                    <img
                      src={`https://cdn.discordapp.com/icons/${guild.id}/${guild.icon}.png?size=64`}
                      alt={guild.name}
                      style={{
                        width: "46px",
                        height: "46px",
                        borderRadius: "50%",
                        objectFit: "cover",
                      }}
                    />
                  ) : (
                    <div
                      style={{
                        width: "46px",
                        height: "46px",
                        borderRadius: "50%",
                        background:
                          "linear-gradient(135deg, #C100FF 0%, #8A2BFF 100%)",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        fontSize: "18px",
                        fontWeight: 800,
                        color: "#F5F5F5",
                      }}
                    >
                      {guild.name.charAt(0)}
                    </div>
                  )}

                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div
                      style={{
                        fontWeight: 700,
                        fontSize: "15px",
                        whiteSpace: "nowrap",
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                      }}
                    >
                      {guild.name}
                    </div>

                    <div
                      style={{
                        fontSize: "12px",
                        color: "#72767d",
                        marginTop: "3px",
                      }}
                    >
                      {guild.accessType}
                    </div>
                  </div>

                  <svg
                    width="18"
                    height="18"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="#72767d"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M9 18l6-6-6-6" />
                  </svg>
                </a>
              ))}
            </div>
          )}
        </div>
      </div>
    </main>
  );
}