import { slugify } from "@/lib/storeShared";
import { BUILDER_MODULES, botModulesOnly, builderModule, type BuilderOptions } from "./catalog";
import { generateReadme } from "./readme";
import { TEMPLATE_FILES, TEMPLATE_INTENTS, TEMPLATE_OFUSCADO, TEMPLATE_VERSION } from "./templateFiles";
import { createHash } from "node:crypto";
import { ofuscarPorteiro } from "./ofuscar";
import { createZip, type ZipEntry } from "./zip";
import { chavePublica, emitirLicenca, empacotar } from "./licenca";

/** Arquivos que mudam em cada pedido (o resto vem igual da pasta bot-template/). */
export const GENERATED_FILES = ["README.md", "package.json", "config.json", "discloud.config", "squarecloud.app"] as const;

export function generatedFiles(opts: BuilderOptions, siteUrl: string): Record<(typeof GENERATED_FILES)[number], string> {
  const slug = slugify(opts.nome) || "meu-bot";
  const pkg = JSON.parse(TEMPLATE_FILES["package.json"]);
  pkg.name = slug;
  const modulos = botModulesOnly(opts.modulos); // ferramentas extras não entram no config.json
  pkg.description = `${opts.nome}: bot para Discord (módulos: ${modulos.join(", ")})`;
  // o código vai criptografado: o Inicializador lê daqui as permissões especiais (intents) que os módulos precisam
  const intents = [...new Set(modulos.flatMap((id) => TEMPLATE_INTENTS[id] ?? []))];
  const config = { nome: opts.nome, cor: opts.cor, status: "Use /ajuda", modulos, intents };
  const nomeHost = opts.nome.replace(/[\r\n=]/g, " ").slice(0, 32);
  return {
    "README.md": generateReadme(opts, siteUrl),
    "package.json": `${JSON.stringify(pkg, null, 2)}\n`,
    "config.json": `${JSON.stringify(config, null, 2)}\n`,
    // hospedagens brasileiras: já vão prontos (o README explica)
    "discloud.config": `NAME=${nomeHost}\nTYPE=bot\nMAIN=index.js\nRAM=100\nVERSION=latest\n`,
    "squarecloud.app": `MAIN=index.js\nMEMORY=256\nVERSION=recommended\nDISPLAY_NAME=${nomeHost}\nDESCRIPTION=Bot para Discord\n`,
  };
}

/** Em qual módulo (ou ferramenta extra) cada arquivo do template entra (null = vai em todo bot). */
export function moduleOfFile(nome: string): string | null {
  return /^src\/modules\/([\w-]+)\.js$/.exec(nome)?.[1] ?? /^extras\/([\w-]+)\//.exec(nome)?.[1] ?? null;
}

/** Onde o arquivo fica dentro do bot (as ferramentas extras vão para a raiz). */
const destinoNoBot = (nome: string) => nome.replace(/^extras\/[\w-]+\//, "");

/** Arquivos do Windows (.bat, .ps1) precisam de quebra de linha CRLF. */
const paraWindows = (nome: string, conteudo: string) => (/\.(bat|cmd|ps1)$/i.test(nome) ? conteudo.replace(/\r?\n/g, "\r\n") : conteudo);

/** Vai dentro do bot.pack: se o index.js (porteiro) for alterado, o bot não liga. */
const SELO = `import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
let h = '';
try { h = createHash('sha256').update(readFileSync(new URL('../../index.js', import.meta.url))).digest('hex'); } catch {}
if (h !== '__HASH__') {
  console.error('❌ O arquivo index.js foi alterado. Baixe o bot de novo em Minhas compras.');
  process.exit(1);
}
`;

/** Arquivos que vão criptografados no bot.pack (o código do bot). */
const vaiNoPacote = (nome: string) => nome === "index.js" || /^src\/.+\.js$/.test(nome);

/** Quem pode usar este bot: o ID da licença (o item do pedido) e o ID do Discord de quem comprou. */
export type LicencaPedido = { id: string; comprador: string };

/**
 * Monta o .zip do "Monte o seu bot" com os módulos escolhidos.
 * O código vem da pasta bot-template/ (empacotada em templateFiles.ts);
 * package.json, config.json e README.md são gerados para cada pedido.
 * O código vai criptografado no bot.pack, e o index.js vira o carregador
 * (bot-template/protegido/index.js) que confere a licença antes de abrir.
 */
export function buildBotZip(opts: BuilderOptions, siteUrl: string, licenca: LicencaPedido) {
  const slug = slugify(opts.nome) || "meu-bot";
  const escolhidos = new Set(opts.modulos);
  const vendidos = new Set(BUILDER_MODULES.map((m) => m.id));
  const entries: ZipEntry[] = [];

  const gerados = generatedFiles(opts, siteUrl);
  for (const nome of GENERATED_FILES) entries.push({ name: `${slug}/${nome}`, data: gerados[nome] });

  const codigo: Record<string, string> = {};
  for (const [nome, conteudo] of Object.entries(TEMPLATE_FILES)) {
    if ((GENERATED_FILES as readonly string[]).includes(nome) || nome.startsWith("protegido/")) continue;
    const modulo = moduleOfFile(nome);
    if (modulo && (!vendidos.has(modulo) || !escolhidos.has(modulo))) continue;
    if (vaiNoPacote(nome)) {
      codigo[nome === "index.js" ? "principal.js" : nome] = TEMPLATE_OFUSCADO[nome] ?? conteudo;
      continue;
    }
    // ferramentas "fora" (ex.: Inicializador) ficam ao lado da pasta do bot, no topo do .zip.
    // O Inicializador vai numa subpasta "Bots ByteUP": o topo mostra só o bot (e, depois do 1º uso, o atalho).
    const fora = modulo ? builderModule(modulo)?.fora : false;
    // o .ps1 nasce oculto no Windows (a pasta mostra só o .bat)
    const hidden = /\.ps1$/i.test(nome);
    let destino: string;
    if (modulo === "inicializador") destino = `Bots ByteUP/${destinoNoBot(nome)}`;
    else if (fora) destino = destinoNoBot(nome);
    else destino = `${slug}/${destinoNoBot(nome)}`;
    entries.push({ name: destino, data: paraWindows(nome, conteudo), hidden });
  }

  const lic = emitirLicenca({ id: licenca.id, comprador: licenca.comprador, bot: opts.nome, site: siteUrl });
  entries.push({ name: `${slug}/licenca.json`, data: `${JSON.stringify(lic, null, 2)}\n` });
  // o "porteiro" (index.js) é embaralhado de um jeito diferente em cada download
  const carregador = ofuscarPorteiro(
    TEMPLATE_FILES["protegido/index.js"].replace("__CHAVE_PUBLICA__", chavePublica()).replace("__VERSAO__", TEMPLATE_VERSION),
  );
  entries.push({ name: `${slug}/index.js`, data: carregador });
  // selo: o código de dentro confere se o porteiro não foi mexido
  const hash = createHash("sha256").update(carregador).digest("hex");
  codigo["src/core/selo.js"] = ofuscarPorteiro(SELO.replace("__HASH__", hash), true);
  codigo["principal.js"] = `import './src/core/selo.js';\n${codigo["principal.js"]}`;
  entries.push({ name: `${slug}/bot.pack`, data: empacotar(codigo, licenca.id) });

  return { fileName: `${slug}.zip`, buffer: createZip(entries), version: TEMPLATE_VERSION };
}
