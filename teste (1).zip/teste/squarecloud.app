MAIN=index.js
MEMORY=256
VERSION=recommended
DISPLAY_NAME=teste
DESCRIPTION=Bot para Discord
