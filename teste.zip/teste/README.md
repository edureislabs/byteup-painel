# teste

Bot para Discord montado na Loja ByteUP. Funciona em **qualquer servidor** e é configurado por comandos, sem mexer no código.

**Módulos:** 🔨 Moderação · 🛡️ AutoMod · 🔐 Verificação · 🚨 Anti-raid · 👋 Boas-vindas · 📜 Logs · 📨 Rastreio de convites · ⭐ Níveis · 🪙 Economia · 👍 Reputação · 🎫 Tickets · ⭐ Avaliação de atendimento · 📝 Formulários · 💡 Sugestões · 📊 Enquetes · 🎉 Sorteios · 🎭 Cargos por botão · ⏳ Cargos temporários · 🔊 Calls temporárias · 📈 Contadores · 🌟 Destaques · 🔢 Jogo de contar · 💤 AFK · 💬 Respostas automáticas · 📣 Anúncios agendados · 🧱 Criador de embeds · 🎂 Aniversários · ⛏️ Status Minecraft · 🧰 Utilidades · 🎲 Diversão · 🎨 Personalização

**Ferramentas:** 📦 Transferidor de dados · 🚀 Inicializador

> Já tinha um bot nosso e está atualizando? Vá direto para **Atualizar o bot sem perder os dados**, mais abaixo.

## Do que você precisa

- **Node.js 18.17 ou mais novo** (recomendado: a versão LTS em https://nodejs.org)
- Uma conta no Discord e permissão de **Gerenciar servidor** no servidor onde o bot vai ficar

## Passo a passo

### 1. Crie o bot no Discord

1. Abra https://discord.com/developers/applications e clique em **New Application**. Dê um nome e confirme.
2. No menu da esquerda, entre em **Bot**. Ali você pode mudar o nome e a foto do bot.
3. Clique em **Reset Token** e copie o token. **Não mostre o token para ninguém**: com ele, qualquer pessoa controla o seu bot.
4. Ainda em **Bot**, desça até **Privileged Gateway Intents** e ligue: **Message Content Intent** e **Server Members Intent**. Clique em **Save Changes**.

### 2. Coloque o token no bot

1. Extraia este .zip numa pasta.
2. Faça uma cópia do arquivo **.env.example** com o nome **.env** (no Windows, se a extensão estiver oculta, confira que o nome ficou só `.env`).
3. Abra o **.env** no Bloco de Notas e cole o token depois de `DISCORD_TOKEN=` (sem espaços nem aspas).

### 3. Ligue o bot

Abra um terminal **dentro da pasta do bot** (no Windows: clique na barra de endereço da pasta, digite `cmd` e aperte Enter) e rode:

```
npm install
npm start
```

Quando aparecer **✅ online**, o terminal mostra um **link para adicionar o bot a um servidor**, já com as permissões certas. Abra o link, escolha o servidor e autorize.

> Os comandos podem levar alguns minutos para aparecer na primeira vez. Se demorar, aperte **Ctrl+R** no Discord.

### 4. Configure no servidor

Tudo é configurado com **/config** (só quem tem *Gerenciar servidor* vê esse comando):

- `/config ver` — mostra tudo o que está configurado
- `/config staff cargo:@Equipe` — cargo da equipe (atende tickets, decide sugestões...)
- `/config cor cor:#5865F2` — cor das mensagens do bot neste servidor
- `/ajuda` — lista todos os comandos

**Importante:** em *Configurações do servidor → Cargos*, arraste o cargo do bot para **cima** dos cargos que ele vai dar, tirar ou punir.

## Módulos

### 🔨 Moderação

Banir, expulsar, castigo, advertências com punição automática, limpar mensagens e trancar canais. Tudo registrado num canal.

**Comandos:** `/banir` `/desbanir` `/expulsar` `/castigo` `/removercastigo` `/advertir` `/advertencias` `/removeradvertencia` `/limpar` `/trancar` `/destrancar` `/lentidao`

**Configuração:** `/config moderacao` → `canal` `dm` `limite`

Para começar:

- `/config moderacao canal canal:#punicoes` — onde as punições ficam registradas
- `/config moderacao limite advertencias:3 acao:Castigo duracao:1h` — punição automática (opcional)
- `/config moderacao dm ativar:False` — se não quiser avisar o membro na DM

### 🛡️ AutoMod

Apaga sozinho convites, links, palavras proibidas, flood, CAPS e menções em massa. Pode dar castigo automático.

**Configuração:** `/config automod` → `ativar` `links` `permitir-site` `convites` `palavra` `flood` `maiusculas` `mencoes` `punicao` `imune` `ignorar-canal` `registro`

Para começar:

- `/config automod ativar ligado:True` — liga o AutoMod (já bloqueia convites)
- `/config automod links bloquear:True` e `/config automod permitir-site site:youtube.com` — links
- `/config automod palavra palavra:...` — adiciona (ou remove) uma palavra proibida
- `/config automod flood limite:5` — no máximo 5 mensagens a cada 5 segundos
- `/config automod registro canal:#automod` — onde registrar o que foi apagado
- Quem tem **Gerenciar mensagens** nunca é afetado. Use `imune` e `ignorar-canal` para outras exceções.

### 🔐 Verificação

Painel com botão "Verificar": a pessoa resolve um desafio rápido e ganha o cargo de membro. Segura contas falsas e raids, com idade mínima da conta.

**Comandos:** `/verificacao`

Para começar:

- `/verificacao configurar cargo:@Membro` — cargo que a pessoa ganha ao se verificar
- Opcional na mesma linha: `remover:@NaoVerificado`, `idade-minima:7` (conta com pelo menos 7 dias) e `registro:#verificacoes`
- `/verificacao painel canal:#verificacao` — envia o painel com o botão **Verificar**
- Dica: deixe os canais do servidor visíveis só para quem tem o cargo de membro; o canal de verificação fica aberto para todos.

### 🚨 Anti-raid

Se entrar gente demais de uma vez, trava o servidor sozinho (verificação máxima e convites pausados), expulsa quem chegar e avisa a equipe. Também barra contas novas demais.

**Comandos:** `/antiraid`

Para começar:

- `/antiraid configurar alerta:#equipe limite:10 segundos:30` — liga a proteção (10 entradas em 30 s = modo raid)
- `acao:` o que fazer com quem entra durante o raid: expulsar (padrão), castigo de 1 hora ou nada
- `idade-minima:3` — expulsa sempre contas com menos de 3 dias (opcional)
- No modo raid o bot sobe a verificação do servidor ao máximo e pausa os convites; encerre pelo botão ou com `/antiraid encerrar`

### 👋 Boas-vindas

Mensagem de entrada e saída personalizável, mensagem na DM de quem entra e até 5 cargos automáticos.

**Configuração:** `/config boasvindas` → `entrada` `saida` `dm` `cargo` `testar`

Para começar:

- `/config boasvindas entrada canal:#boas-vindas` — mensagem quando alguém entra
- `/config boasvindas saida canal:#saidas` — mensagem quando alguém sai
- `/config boasvindas cargo cargo:@Membro` — cargo automático (até 5)
- `/config boasvindas testar` — mostra como fica
- Variáveis nas mensagens: `{usuario}` `{nome}` `{tag}` `{servidor}` `{membros}`

### 📜 Logs

Registra mensagens apagadas e editadas, entradas e saídas, apelidos, cargos, banimentos, canais e calls.

**Configuração:** `/config logs` → `canal` `tipo`

Para começar:

- `/config logs canal canal:#logs` — liga os registros
- `/config logs tipo tipo:... ligado:False` — desliga um tipo (mensagens, membros, banimentos, canais, voz)

### 📨 Rastreio de convites

Mostra quem convidou quem, conta entradas, saídas e contas falsas e tem ranking de convites. Ótimo para sorteios por convite.

**Comandos:** `/convites`

Para começar:

- Dê ao bot a permissão **Gerenciar servidor** (sem ela o Discord não mostra os convites)
- `/convites configurar canal:#entradas` — avisa quem entrou e quem convidou
- `/convites ver`, `/convites ranking` e `/convites quem usuario:@pessoa`
- Contas com menos de 7 dias contam como **falsas** (mude com `dias-falso:`)

### ⭐ Níveis

XP por mensagem, aviso quando alguém sobe de nível, ranking e cargos de recompensa por nível.

**Comandos:** `/rank` `/top` `/xp`

**Configuração:** `/config niveis` → `ativar` `aviso` `recompensa` `xp` `ignorar-canal`

Para começar:

- Já vem ligado: cada mensagem vale de 15 a 25 XP (uma vez por minuto).
- `/config niveis aviso canal:#niveis` — onde avisar quem sobe de nível
- `/config niveis recompensa nivel:10 cargo:@Veterano` — cargo ao chegar num nível
- `/config niveis xp minimo:15 maximo:25 intervalo:60` — quanto XP cada mensagem vale

### 🪙 Economia

Moeda do servidor com carteira e banco, diário, trabalho, apostas, ranking e loja de cargos.

**Comandos:** `/saldo` `/diario` `/trabalhar` `/pagar` `/depositar` `/sacar` `/apostar` `/ricos` `/loja` `/comprar` `/eco`

**Configuração:** `/config economia` → `moeda` `ganhos` `loja-adicionar` `loja-remover`

Para começar:

- `/config economia moeda nome:coins emoji:🪙` — nome e emoji da moeda
- `/config economia ganhos diario:500` — valores do /diario e do /trabalhar
- `/config economia loja-adicionar nome:VIP preco:5000 cargo:@VIP` — coloca um cargo à venda

### 👍 Reputação

Cada membro dá +1 de reputação para alguém uma vez por dia. Ranking e cargos de recompensa por pontos.

**Comandos:** `/rep` `/reputacao`

Para começar:

- `/rep usuario:@pessoa` — cada membro dá 1 ponto por dia
- `/reputacao recompensa pontos:10 cargo:@Confiável` — cargo ao chegar em 10 pontos
- `/reputacao ranking` e `/reputacao ver`

### 🎫 Tickets

Painel com botão, canal privado para cada atendimento, assumir, fechar e histórico em .txt no canal de registro.

**Comandos:** `/ticket`

**Configuração:** `/config tickets` → `categoria` `equipe` `registro` `mensagem` `limite`

Para começar:

- `/config tickets categoria categoria:Atendimento` — onde os canais são criados
- `/config tickets equipe cargo:@Suporte` — quem atende (padrão: o cargo do /config staff)
- `/config tickets registro canal:#tickets-log` — recebe o histórico em .txt
- `/ticket painel` — envia o painel com o botão **Abrir ticket**
- Com assuntos: `/ticket assunto adicionar nome:Compras emoji:🛒 categoria:Vendas equipe:@Vendas` (até 25; cada um pode ter categoria, equipe e mensagem própria)
- Depois `/ticket painel modo:Menu de assuntos` — a pessoa escolhe o assunto num menu. `/ticket assunto lista` mostra todos

### ⭐ Avaliação de atendimento

Ao fechar um ticket, quem abriu dá de 1 a 5 estrelas e um comentário na DM. Ranking dos atendentes. Precisa do módulo Tickets.

**Comandos:** `/avaliacoes`

Para começar:

- Já vem ligada: quando um ticket fecha, quem abriu recebe a avaliação na DM
- `/avaliacoes configurar canal:#avaliacoes` — onde as notas aparecem
- `/avaliacoes ranking` e `/avaliacoes atendente usuario:@pessoa`
- Assuma o ticket (botão **Assumir**) para a nota contar para o atendente certo

### 📝 Formulários

Candidatura para a equipe, parceria, denúncia: até 5 perguntas, botão para responder e a equipe aprova ou recusa (com cargo automático).

**Comandos:** `/formulario`

Para começar:

- `/formulario criar titulo:Candidatura para a equipe canal:#candidaturas cargo:@Ajudante`
- `/formulario pergunta formulario:... texto:Qual a sua idade?` — até 5 perguntas (limite do Discord), de até 45 letras
- `/formulario painel formulario:...` — envia o botão **Preencher**
- A equipe aprova ou recusa pelos botões; ao aprovar, a pessoa ganha o cargo (se configurado) e recebe a resposta na DM

### 💡 Sugestões

Sugestões com votos 👍/👎, tópico para discutir e aprovação ou recusa pela equipe, com motivo.

**Comandos:** `/sugerir`

**Configuração:** `/config sugestoes` → `canal`

Para começar:

- `/config sugestoes canal canal:#sugestoes` — onde as sugestões são publicadas

### 📊 Enquetes

Enquetes com até 5 opções, resultado ao vivo e encerramento automático.

**Comandos:** `/enquete` `/encerrarenquete`

Para começar:

- `/enquete pergunta:... opcoes:Sim | Não | Talvez duracao:1d` — cria uma enquete

### 🎉 Sorteios

Sorteios com botão de participar, cargo obrigatório, vários vencedores e sortear de novo.

**Comandos:** `/sorteio`

Para começar:

- `/sorteio criar premio:... duracao:2d vencedores:1` — cria um sorteio

### 🎭 Cargos por botão

Painéis onde os membros pegam ou tiram cargos sozinhos, clicando em botões.

**Comandos:** `/cargos`

Para começar:

- `/cargos painel titulo:Escolha seus cargos` — cria o painel
- `/cargos adicionar painel:<link da mensagem> cargo:@Cargo emoji:🎮` — coloca um botão

### ⏳ Cargos temporários

Dá um cargo por um tempo (ex.: VIP por 30 dias) e ele sai sozinho no fim do prazo, mesmo se o bot reiniciar.

**Comandos:** `/cargotemp`

Para começar:

- `/cargotemp dar usuario:@pessoa cargo:@VIP duracao:30d` — o cargo sai sozinho em 30 dias
- Dar de novo o mesmo cargo renova o prazo; `/cargotemp lista` mostra os ativos
- `/cargotemp registro canal:#logs` — registra quando cada cargo sai

### 🔊 Calls temporárias

Entrou em "➕ Criar sala", ganha uma call própria que some quando esvazia. O dono renomeia, limita, tranca e expulsa.

**Comandos:** `/salas` `/sala`

Para começar:

- `/salas configurar` — cria a call **➕ Criar sala** (ou escolha uma com `canal:`)
- `nome:Sala de {nome}` e `limite:5` mudam o padrão das salas
- Dentro da própria sala, o dono usa `/sala nome`, `/sala limite`, `/sala trancar`, `/sala permitir`, `/sala expulsar`
- Se o dono sair, outra pessoa pode usar `/sala reivindicar`

### 📈 Contadores

Canais que mostram "👥 Membros: 1.234", online e boosts, atualizando sozinhos.

**Comandos:** `/contadores`

Para começar:

- `/contadores criar tipo:Membros` — cria um canal "👥 Membros: 1.234" (também: online, boosts, canais, cargos)
- `nome:` muda o texto; `{n}` vira o número. Atualiza a cada 10 minutos (limite do Discord para renomear canais)

### 🌟 Destaques

Mensagens que juntam ⭐ suficientes vão para o canal de destaques, com o contador sempre atualizado.

**Comandos:** `/destaques`

Para começar:

- `/destaques configurar canal:#destaques minimo:3` — mensagens com 3 ⭐ vão para o destaque
- `emoji:` troca a ⭐ por outro emoji (pode ser um do servidor)

### 🔢 Jogo de contar

Canal onde todo mundo conta 1, 2, 3... sem a mesma pessoa repetir. Errou, volta para o 1. Com recorde do servidor.

**Comandos:** `/contagem`

Para começar:

- `/contagem canal canal:#contar` — liga o jogo
- Dica: coloque esse canal nas exceções do AutoMod (`/config automod ignorar-canal`) e dos Níveis (`/config niveis ignorar-canal`)

### 💤 AFK

/afk motivo: quem te marcar recebe o aviso. Quando você volta, o AFK sai sozinho e o bot mostra quem te chamou.

**Comandos:** `/afk`

Para começar:

- Cada membro usa `/afk motivo:almoçando`. Para mudar o apelido para "[AFK]", o bot precisa da permissão **Gerenciar apelidos**.

### 💬 Respostas automáticas

O bot responde sozinho quando alguém escreve uma palavra (ex.: "ip do servidor"). Cada resposta vira um atalho: /tag regras.

**Comandos:** `/autoresposta` `/tag`

Para começar:

- `/autoresposta adicionar gatilho:ip do servidor resposta:O IP é jogar.exemplo.com` — cria uma resposta
- `modo:` contém a palavra (padrão), é exatamente ou começa com
- `/tag nome:...` mostra qualquer resposta salva; `/autoresposta lista` mostra todas

### 📣 Anúncios agendados

Mensagens que saem numa data marcada ou repetem sozinhas (ex.: regras toda semana), com cargo marcado e imagem.

**Comandos:** `/anuncio`

Para começar:

- `/anuncio criar canal:#avisos mensagem:Leiam as regras! quando:17/11 09:00 repetir:7d`
- `quando:` aceita "25/12 09:00", "18:30", "9h" ou "em 2h"; `repetir:` aceita "12h", "1d", "7d" (mínimo 10 minutos)
- Para marcar um cargo que não é mencionável, o bot precisa da permissão **Mencionar @everyone**

### 🧱 Criador de embeds

Monta mensagens bonitas (título, texto, cor, imagem, rodapé e botões de link) num formulário, sem saber código. Também edita.

**Comandos:** `/embed`

Para começar:

- `/embed criar canal:#regras botao1:Site | https://seusite.com` — abre o formulário (título, texto, cor, imagem, rodapé)
- `/embed editar mensagem:<link da mensagem>` — muda um embed que o bot enviou

### 🎂 Aniversários

Cada membro cadastra o dia. No aniversário, o bot dá parabéns no canal e um cargo especial por 24 horas. Lista dos próximos aniversários.

**Comandos:** `/aniversario`

Para começar:

- `/aniversario configurar canal:#geral cargo:@Aniversariante` — onde dar parabéns e o cargo do dia
- Cada membro usa `/aniversario definir dia:14 mes:novembro`
- `/aniversario proximos` mostra os próximos. O horário segue o fuso do Brasil.

### ⛏️ Status Minecraft

Mostra se o servidor de Minecraft (Java) está online, quantos jogam e a versão. Painel que se atualiza sozinho a cada 2 minutos.

**Comandos:** `/minecraft`

Para começar:

- `/minecraft status ip:jogar.seuservidor.com` — mostra na hora (servidores Java)
- `/minecraft painel ip:jogar.seuservidor.com canal:#status` — mensagem que se atualiza a cada 2 minutos

### 🧰 Utilidades

Informações de membros e do servidor, avatar e lembretes.

**Comandos:** `/userinfo` `/serverinfo` `/avatar` `/lembrete`

Não precisa configurar nada: é só usar os comandos.

### 🎲 Diversão

Cara ou coroa, dados, bola 8, escolher entre opções e ship.

**Comandos:** `/caracoroa` `/dado` `/8ball` `/escolher` `/ship`

Não precisa configurar nada: é só usar os comandos.

### 🎨 Personalização

Personalize 100% do bot: todos os textos, botões (texto, emoji, cor, mostrar ou esconder), modais, cores, emojis, aparência dos embeds e status. E crie seus próprios painéis com botões ou menu (dar cargo, responder, abrir formulário, abrir ticket, link) e formulários. Edita num painel no seu PC e aplica com /personalizar, mesmo numa hospedagem.

**Comandos:** `/personalizar` `/painel`

Para começar:

- No Discord, use `/personalizar baixar`: o bot manda o arquivo **personalizacao.json** (só para você, que criou o bot)
- Abra o **Personalizar bot.html** (está na pasta do bot) com dois cliques, clique em **Abrir arquivo** e escolha o arquivo
- Mude textos, botões (texto, emoji, cor, mostrar/esconder), modais, cores, emojis, a aparência dos embeds e o status. A prévia mostra como fica no Discord
- Na parte **Criar**, monte seus **Painéis** (botões ou menu que dão cargo, respondem, abrem formulário, abrem ticket ou levam a um link) e **Formulários**
- Clique em **Salvar** e, no Discord, use `/personalizar aplicar arquivo:` com o arquivo salvo. Vale na hora, sem reiniciar
- Publique um painel criado com `/painel enviar`. Se mudar o painel e aplicar de novo, os já enviados se atualizam sozinhos
- Funciona igual com o bot numa hospedagem: o arquivo vai e volta pelo Discord. `/personalizar resetar` volta tudo ao padrão

### 📦 Transferidor de dados

Para trocar ou atualizar o bot sem perder nada: dois cliques, escolhe a pasta do bot antigo e ele leva XP, dinheiro, configurações e token. Para Windows.

Veja como usar em **Atualizar o bot sem perder os dados**.

### 🚀 Inicializador

Liga o bot com dois cliques, sem digitar comandos. Acha os bots no seu PC, mostra o mais novo e o mais antigo e ajuda a apagar cópias velhas. Para Windows.

O arquivo **`Iniciar bot.bat`** fica fora da pasta do bot (pode deixar na Área de Trabalho). Dois cliques e ele:

1. Procura no seu PC as pastas de bot (na primeira vez demora um pouco; depois ele lembra).
2. Mostra a lista com o nome, a pasta, a data da versão e a última atividade de cada um, marcando o **mais novo** e o **mais antigo**.
3. **Iniciar:** confere o Node.js, pede o token se faltar o `.env`, instala o que precisar e abre o bot numa janela.
4. **Apagar:** manda uma cópia velha para a Lixeira (avisa antes se ela tiver dados mais novos que a outra).

> Use o Inicializador enquanto o bot roda no seu PC. Quando for para uma hospedagem, siga **Deixar o bot ligado 24 horas**.

### ⚙️ Base do bot

**Comandos:** `/ajuda` `/ping` `/sobre` `/config ver` `/config cor` `/config staff`

## Atualizar o bot sem perder os dados

Comprou mais módulos ou recebeu uma versão nova? Os dados (XP, dinheiro, advertências, configurações) ficam na pasta **`data`** e o token no **`.env`**. O .zip novo nunca traz esses arquivos, então nada se perde:

1. Desligue o bot antigo e extraia este .zip numa pasta **nova**.
2. Na pasta nova, dê **dois cliques em `Transferir dados.bat`**.
3. Escolha a pasta do bot antigo e confirme. Ele copia a `data` e o `.env`, guarda uma cópia de segurança e já roda o `npm install`.
4. Ligue o bot novo com `npm start`.

## Deixar o bot ligado 24 horas

O bot só fica online enquanto estiver rodando. No seu PC, ele desliga quando você desliga o computador. Para ficar online sempre, use uma **hospedagem**. Este bot já vem pronto para as mais usadas no Brasil.

**Antes de qualquer hospedagem:**

1. Ligue o bot no seu PC uma vez e confira que funciona (assim o `.env` já está certo).
2. Monte o arquivo para enviar: abra a pasta do bot, selecione **tudo o que está dentro dela, menos a pasta `node_modules`**, clique com o botão direito → **Enviar para → Pasta compactada**. O `discloud.config` e o `squarecloud.app` precisam ficar na **raiz** do .zip, não dentro de outra pasta.
3. O `.env` (com o token) vai junto. **Nunca mande esse .zip para ninguém.**

### Discloud

1. Crie a conta em https://discloud.com e entre no servidor deles no Discord (o envio é feito pelo bot da Discloud ou pelo painel do site).
2. O arquivo **`discloud.config`** já vem pronto:

```
TYPE=bot
MAIN=index.js
RAM=100
VERSION=latest
```

3. Envie o .zip pelo painel (Upload) ou, no Discord, com o comando `.upconfig` no canal de comandos deles.
4. Se o bot cair por falta de memória, aumente o `RAM` (ex.: `RAM=200`).

### Square Cloud

1. Crie a conta em https://squarecloud.app.
2. O arquivo **`squarecloud.app`** já vem pronto (bots precisam de pelo menos 256 MB):

```
MAIN=index.js
MEMORY=256
VERSION=recommended
DISPLAY_NAME=teste
```

3. No painel, clique em **Upload** e envie o .zip. Para o bot voltar sozinho se cair, adicione a linha `AUTORESTART=true` (se o seu plano permitir).

### Hospedagem com painel (Pterodactyl e parecidas)

1. Crie um servidor do tipo **Node.js** (versão 18 ou mais nova).
2. Envie os arquivos pelo gerenciador de arquivos do painel (sem a `node_modules`).
3. Arquivo principal: `index.js` · comando de início: `npm start` (ou `node index.js`).
4. Se o painel tiver **variáveis de ambiente**, coloque `DISCORD_TOKEN` lá; senão, envie o `.env`.

### VPS (Linux / Ubuntu)

```
# instalar o Node.js 22
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
sudo apt install -y nodejs

# na pasta do bot (envie os arquivos com o WinSCP ou o FileZilla)
npm install
sudo npm install -g pm2
pm2 start index.js --name meu-bot
pm2 save
pm2 startup   # rode o comando que ele mostrar: o bot volta sozinho quando a VPS reinicia
```

Comandos úteis: `pm2 logs meu-bot` (ver o que o bot está fazendo) · `pm2 restart meu-bot` (reiniciar).

### Cuidado com os dados na hospedagem

- As informações do bot (XP, dinheiro, configurações) ficam na pasta **`data`**, que o bot cria e atualiza sozinho.
- **Antes de enviar uma versão nova**, baixe a pasta `data` da hospedagem (pelo gerenciador de arquivos ou pela opção de backup do painel) e coloque no .zip novo. Senão o bot volta zerado.
- Faça backup da pasta `data` de vez em quando.

## Personalizar

No arquivo **config.json**:

- `nome`: nome mostrado nas mensagens do bot
- `cor`: cor padrão das mensagens (cada servidor pode trocar com `/config cor`)
- `status`: frase que aparece no perfil do bot
- `modulos`: módulos ligados (para desligar um, tire o nome dele da lista)
- `fuso` (opcional): fuso horário dos aniversários, ex.: `"fuso": "America/Manaus"` (padrão: horário de Brasília)

Depois de mudar, reinicie o bot (Ctrl+C no terminal e `npm start` de novo).

### Textos, cores, emojis e status (módulo Personalização)

Todos os textos, botões (texto, emoji, cor, mostrar/esconder), modais, cores e o status do bot podem ser trocados sem mexer no código. Também dá para criar painéis com botões ou menu e formulários próprios:

1. No Discord: `/personalizar baixar` (só quem criou o bot no Developer Portal pode usar).
2. Abra o **Personalizar bot.html** (na pasta do bot) no navegador e abra o arquivo baixado.
3. Edite e clique em **Salvar**.
4. No Discord: `/personalizar aplicar` com o arquivo salvo. Vale na hora.
5. Painéis criados: publique com `/painel enviar` (veja todos com `/painel lista`).

A personalização fica em `data/personalizacao.json` (o Transferidor de dados leva junto). Se um servidor definir uma mensagem própria no `/config` (ex.: boas-vindas), ela tem prioridade nele.

## Problemas comuns

- **"Falta o token do bot"**: o arquivo `.env` não existe ou o `DISCORD_TOKEN` está vazio.
- **"An invalid token was provided"**: o token está errado. Gere outro em *Bot → Reset Token*.
- **"Used disallowed intents"**: ligue **Message Content Intent** e **Server Members Intent** no Developer Portal (passo 1).
- **O bot não consegue dar cargo ou punir alguém**: o cargo do bot precisa estar acima do cargo da pessoa, e o bot precisa da permissão. Use o link do terminal para convidar de novo, se precisar.
- **Os comandos não aparecem**: espere alguns minutos e aperte Ctrl+R no Discord. Para testes, coloque o ID do servidor em `GUILD_ID` no `.env`: os comandos aparecem na hora nele.

## Quer algo exclusivo?

Este bot é genérico, feito para funcionar em qualquer servidor. Recursos sob medida (cards com imagem, painel web, integrações, comandos especiais) são feitos por encomenda: abra um ticket no servidor da ByteUP. Loja: https://byteup-painel.vercel.app/loja
